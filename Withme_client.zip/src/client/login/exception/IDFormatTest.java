package client.login.exception;

public class IDFormatTest {
	private String iD;

	public String getID() {
		return iD;
	}

	public void setID(String iD) throws FormatException {
		System.out.println("setID :" + iD.length());
		if (iD == null || iD.trim().equals("")) {
			System.out.println("ID null 오류발생 ");
			throw new FormatException("----- 아이디를 입력하여 주세요. ----");

		} else if (iD.length() < 5 || iD.length() > 12) {
			System.out.println("ID 오류발생 ");
			throw new FormatException("아이디는 5자 이상 15자 이하 입니다.");
		} else {
			
		}
	}

	 public class MailFormatTest {
		private String Mail;

		public String getMail() {
			return Mail;
		}

		public void setMail(String mail) throws FormatException {
			if (mail == null || mail.trim().equals("")) {
				System.out.println("Mail null 오류발생 ");
				throw new FormatException("----- 메일을 입력하여 주세요. -----");
			}
		}
	}

	 public class LoLNickFormatTest {
		private String Nick;

		public String getNick() {
			return Nick;
		}

		public void setNick(String nick) throws FormatException {
			if (nick == null || nick.trim().equals("")) {
				System.out.println("NickName null 오류발생 ");
				throw new FormatException("----- 닉네임을 입력하여 주세요. -----");
			}

		}
	}
}
