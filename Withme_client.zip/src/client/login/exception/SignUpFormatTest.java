package client.login.exception;

public class SignUpFormatTest {
	private String iD;
	private String pw;
	private String Mail;
	private String Nick;

	public String getID() {
		return iD;
	}

	public String getPw() {
		return pw;
	}

	public String getMail() {
		return Mail;
	}
	
	public String getNick() {
		return Nick;
	}

	public void setID(String iD) throws FormatException {
		System.out.println("setID :" + iD.length());
		if (iD == null || iD.trim().equals("")) {
			System.out.println("ID null 오류발생 ");
			throw new FormatException(" -아이디를 입력하여 주세요-");

		} else if (!(iD.length() >= 5 && iD.length() <= 12)) {
			System.out.println("ID 오류발생 ");
			throw new FormatException("아이디는 5자 이상 12자 이하 입니다");
		}
	}

	public void setPw(String pw) throws FormatException {
		if (pw.trim().equals("")) {
			System.out.println("password null 오류발생 ");
			throw new FormatException(" -비밀번호을 입력하여 주세요-");
		} else if (pw.length() > 15) {
			System.out.println("password 글자제한 오류");
			throw new FormatException("비밀번호를 15글자 이하로 입력하여 주세요");
		}
	}

	public void setMail(String mail) throws FormatException {
		if (mail == null || mail.trim().equals("")) {
			System.out.println("Mail null 오류발생 ");
			throw new FormatException(" -메일을 입력하여 주세요-");
		}else if (mail.length() > 30) {
			System.out.println("password 글자제한 오류");
			throw new FormatException("메일은 30글자 이하로 입력하여 주세요");
		}
	}

	public void setNick(String nick) throws FormatException {
		if (nick == null || nick.trim().equals("")) {
			System.out.println("NickName null 오류발생 ");
			throw new FormatException(" -닉네임을 입력하여 주세요-");
		} else if (nick.length() > 15) {
			System.out.println("Nick 글자제한 오류");
			throw new FormatException("닉네임을 15글자 이하로 입력하여 주세요");
		}
	}
}
