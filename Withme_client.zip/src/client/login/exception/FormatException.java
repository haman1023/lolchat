package client.login.exception;

public class FormatException extends Exception{
	public FormatException(String message) {
		super(message);
	}
}

