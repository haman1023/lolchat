package client.login.signup;

import java.io.IOException;
import java.net.Socket;

import javax.swing.JOptionPane;

import client.login.LoginController;
import client.login.exception.FormatException;
import client.login.exception.SignUpFormatTest;
import client.main.WaitingRoomController;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import vo.UserVO;

public class SignUpController{

	public static final int SERVER_PORT = 5010;
	public static final String SERVER_IP ="192.168.37.1";
	
	boolean idCheck = false;
	boolean nickCheck = false;
	boolean properId = true;
	
	 private TextField txtID,txtLolID,txtEmail;
	 private PasswordField txtPw,txtPw2;
	 private Label labelID,labelPw,labelMail,labelLoLNick;
	 private Button btnSuccess,btnClose,btnIdCheck,btnNickCheck;
	 private ComboBox<String> combo_box,combo_box2;
	 private ObservableList<String> list = FXCollections.observableArrayList(
			"unRanked","Iron Ⅳ","Iron Ⅲ","Iron Ⅱ","Iron Ⅰ"
			,"Bronze Ⅳ","Bronze Ⅲ","Bronze Ⅱ","Bronze Ⅰ"
			,"Silver Ⅳ","Silver Ⅲ","Silver Ⅱ","Silver Ⅰ"
			,"Gold Ⅳ","Gold Ⅲ","Gold Ⅱ","Gold Ⅰ"
			,"Platinum Ⅳ","Platinum Ⅲ","Platinum Ⅱ","Platinum Ⅰ"
			,"Diamond Ⅳ","Diamond Ⅲ","Diamond Ⅱ","Diamond Ⅰ"
			,"Master","GrandMaster","Challenger");
	 private ObservableList<String> list2 = FXCollections.observableArrayList(
			"unRanked","Iron Ⅳ","Iron Ⅲ","Iron Ⅱ","Iron Ⅰ"
			,"Bronze Ⅳ","Bronze Ⅲ","Bronze Ⅱ","Bronze Ⅰ"
			,"Silver Ⅳ","Silver Ⅲ","Silver Ⅱ","Silver Ⅰ"
			,"Gold Ⅳ","Gold Ⅲ","Gold Ⅱ","Gold Ⅰ"
			,"Platinum Ⅳ","Platinum Ⅲ","Platinum Ⅱ","Platinum Ⅰ"
			,"Diamond Ⅳ","Diamond Ⅲ","Diamond Ⅱ","Diamond Ⅰ"
			,"Master","GrandMaster","Challenger");
	
	WaitingRoomController main;
	LoginController login;
	Socket socket;
	
	public SignUpController() {
		
	}
	
	public SignUpController(WaitingRoomController main, LoginController login) {
		this.main = main;
		this.login = login;
		showSignUpContoller();
	}
	
	public void showSignUpContoller() {
		try {
			Parent p = FXMLLoader.load(SignUpController.class.getResource("signUp.fxml"));
			Stage dialog = new Stage(StageStyle.DECORATED);
			dialog.initModality(Modality.WINDOW_MODAL);
			dialog.initOwner(login.btnLogin.getScene().getWindow());
			txtID = (TextField)p.lookup("#txtID");
			txtLolID = (TextField)p.lookup("#txtLolID");
			txtEmail = (TextField)p.lookup("#txtEmail");
			txtPw = (PasswordField)p.lookup("#txtPw");
			txtPw2 = (PasswordField)p.lookup("#txtPw2");
			btnSuccess = (Button)p.lookup("#btnSuccess");
			btnClose = (Button)p.lookup("#btnClose");
			btnIdCheck = (Button)p.lookup("#btnIdCheck");
			btnNickCheck =(Button)p.lookup("#btnNickCheck");
			combo_box = (ComboBox)p.lookup("#combo_box");
			combo_box2 = (ComboBox)p.lookup("#combo_box2");
			labelID = (Label)p.lookup("#labelID");
			labelPw = (Label)p.lookup("#labelPw");
			labelMail = (Label)p.lookup("#labelMail");
			labelLoLNick = (Label)p.lookup("#labelLoLNick");
			
			
			combo_box.setItems(list);
			combo_box.getSelectionModel().select(0);
			combo_box2.setItems(list2);
			combo_box2.getSelectionModel().select(0);
			
			btnIdCheck.setOnAction(e-> {
				idCheck = true;
				handleBtnIdCheck(e);
			});
			
			btnSuccess.setOnAction(e-> {
				
				if(!idCheck) {
					JOptionPane.showMessageDialog(null,"아이디 중복 검사를 해주세요.");
				}else if(!nickCheck) {
					JOptionPane.showMessageDialog(null,"Lol 아이디 중복 검사를 해주세요.");
				}else if(!properId){
					JOptionPane.showMessageDialog(null,"적절한 아이디가 아닙니다.");
				}else {
					handlerBtnSuccess(e);
				}
			});
			btnClose.setOnAction(e-> {
				Stage stage = (Stage)btnClose.getScene().getWindow();
				stage.close();
			});
			btnNickCheck.setOnAction(e-> {
				nickCheck = true;
				handleBtnNickCheck(e);
			});

			txtLolID.setOnKeyPressed(key->{
				if(key.getCode().equals(KeyCode.ENTER)) {
					btnNickCheck.fire();
				}
			});
			Scene scene = new Scene(p);

			dialog.setTitle("회원가입 화면");
			dialog.setScene(scene);
			dialog.setResizable(false);
			dialog.show();
		} catch (IOException e) {
			System.out.println("찾을수없음");
		}
	}
	public void handleBtnNickCheck(ActionEvent event) {
		String Nick = txtLolID.getText();
		System.out.println(Nick);
		if(Nick.isEmpty()) {
			JOptionPane.showMessageDialog(null,"닉네임을 입력해주세요.");
		}else {
			main.btnNickCheck(Nick);
		}
	}
	
	public void handleBtnIdCheck(ActionEvent event){
		
		String userID = txtID.getText();
		System.out.println(userID);
		if(userID.isEmpty()) {
			JOptionPane.showMessageDialog(null,"아이디를 입력해주세요.");
			properId = false;
		}else if(userID.length() < 5){
			JOptionPane.showMessageDialog(null,"아이디는 5자 이상 이여야 합니다.");
			properId = false;
		}else if(userID.length() > 12){
			JOptionPane.showMessageDialog(null,"아이디는 12자 이하 이여야 합니다.");	
			properId = false;
		}else {
			properId = true;
			main.btnIDCheck(userID);
		}
	}
	
	public void handlerBtnSuccess(ActionEvent event) {
		
		SignUpFormatTest signUpFormatTest = new SignUpFormatTest();
		 //아이디 체크
		String userID = txtID.getText();
		System.out.println(userID);
		try {
			labelID.setText("");
			signUpFormatTest.setID(userID);
		} catch (FormatException e) {
			System.out.println(e.getMessage());
			labelID.setText(e.getMessage());
			return;	
		}
		
		// 비밀번호 체크
		String password = txtPw.getText();
		try {
			labelPw.setText("");
			signUpFormatTest.setPw(password);
		} catch (FormatException e1) {
			System.out.println(e1.getMessage());
			labelPw.setText(e1.getMessage());
			return;
		}
			
		//email null값 제어
		String email = txtEmail.getText();
		System.out.println(email.length());
		try {
			labelMail.setText("");
			signUpFormatTest.setMail(email);
		} catch (FormatException e) {
			System.out.println(e.getMessage());
			labelMail.setText(e.getMessage());
			return;
		}
		
		//lolNickName null값 제어
		String lolID = txtLolID.getText();
		System.out.println(lolID.length());
		try {
			labelLoLNick.setText("");
			signUpFormatTest.setNick(lolID);
		} catch (FormatException e) {
			System.out.println(e.getMessage());
			labelLoLNick.setText(e.getMessage());
			return;
		}
		String soloRank = (String)combo_box.getValue();
		String freeRank = (String)combo_box2.getValue();
		
		UserVO userVO = new UserVO(userID,password,email,lolID,soloRank,freeRank);
		if(txtPw.getText().equals(txtPw2.getText())) {
			main.signUp(userVO);
		}else {
			JOptionPane.showMessageDialog(null,"비밀번호가 일치하지 않습니다.");
			return;
		}
		
		System.out.println(userVO.getUserID());
		
		Stage stage = (Stage)btnClose.getScene().getWindow();
		stage.close();
	}
}
