package client.login;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import client.login.findcontrol.FindController;
import client.login.signup.SignUpController;
import client.main.Main;
import client.main.WaitingRoomController;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;


public class LoginController implements Initializable {

	
	public Button btnLogin;
	private Button btnIdPw;	
	private Button btnSignUp;
	private TextField id;
	private PasswordField pwd;

	WaitingRoomController main;
	FindController findController;
	Parent parent;
	
	
	public LoginController(WaitingRoomController main) {
		this.main = main;
		showSignUp();
	}
	
	private void showSignUp() {
		try {
			parent = FXMLLoader.load(LoginController.class.getResource("login.fxml"));
			btnLogin = (Button)parent.lookup("#btnLogin");
			btnIdPw = (Button)parent.lookup("#btnIdPw");
			btnSignUp = (Button)parent.lookup("#btnSignUp");
			id = (TextField)parent.lookup("#idTxt");
			pwd = (PasswordField)parent.lookup("#pwdTxt");
			
			id.setOnKeyPressed(key->{
				if(key.getCode().equals(KeyCode.ENTER)) {
					Platform.runLater(()->pwd.requestFocus());
				}
			});
			pwd.setOnKeyPressed(key->{
				if(key.getCode().equals(KeyCode.ENTER)) {
					btnLogin.fire();
				}
			});
			
			btnSignUp.setOnAction(e -> handleBtnSingUp(e));
			btnIdPw.setOnAction(e -> handleBtnIdPw(e));
			btnLogin.setOnAction(e->handleBtnLogin(e));
			Main.stackPane.getChildren().add(parent);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
	}

	public void handleBtnSingUp(ActionEvent e) {
			try {
				SignUpController sc = new SignUpController(main, this);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
	}

	public void handleBtnIdPw(ActionEvent e) {
		try {
			 findController = new FindController(main, this);
		} catch (Exception e1) {
		}

	}
	
	public void handleBtnLogin(ActionEvent e) {
		
		String strId = id.getText();
		String strPwd = pwd.getText();
		
		if(strId.equals("") || strPwd.equals("")) {
			receiveLoginFail();
			return;
		}
		String msg = strId + "|" + strPwd;
		main.handleLogin(msg);
	}
	
	public void receiveLoginOK() {
		Main.stackPane.getChildren().remove(1);
		
	}
	
	public void receiveLoginFail() {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("로그인 실패");
		alert.setHeaderText("로그인 실패 : 아래 메시지를 확인해주세요.");
		alert.setContentText("아이디 또는 비밀번호를 확인해주세요.");
		alert.showAndWait();
		id.setText("");
		pwd.setText("");
	}
	
	public void reveiveLoginDuplicate() {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("로그인 실패");
		alert.setHeaderText("로그인 실패 : 아래 메시지를 확인해주세요.");
		alert.setContentText("이미 로그인 중인 아이디입니다.");
		alert.showAndWait();
		id.setText("");
		pwd.setText("");
	}

}
