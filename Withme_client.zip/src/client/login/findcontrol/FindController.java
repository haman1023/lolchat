package client.login.findcontrol;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import client.login.LoginController;
import client.main.WaitingRoomController;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class FindController implements Initializable {

	Button btnClose, btnID, btnPassword;

	WaitingRoomController main;
	LoginController login;

	public FindController(WaitingRoomController main, LoginController login) {
		this.main = main;
		this.login = login;
		showFindController();
	}

	public void showFindController() {
		try {
			Parent p = FXMLLoader.load(FindController.class.getResource("findIdPw.fxml"));
			Stage dialog = new Stage(StageStyle.DECORATED);
			dialog.initModality(Modality.WINDOW_MODAL);
			dialog.initOwner(login.btnLogin.getScene().getWindow());

			btnClose = (Button) p.lookup("#btnClose");
			btnClose.setOnAction(e -> dialog.close());
			btnID = (Button) p.lookup("#btnID");

			btnID.setOnAction(e -> handleBtnID(e));
			btnPassword = (Button) p.lookup("#btnPassword");
			btnPassword.setOnAction(e -> handleBtnPassword(e));

			Scene scene = new Scene(p);
			dialog.setTitle("아이디와 비밀번호찾기");
			dialog.setScene(scene);
			dialog.setResizable(false);
			dialog.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

	}

	public void handleBtnID(ActionEvent e) {
		System.out.println("아이디 찾기");

		Stage dialog = new Stage(StageStyle.DECORATED);
		dialog.initModality(Modality.WINDOW_MODAL);
		dialog.initOwner(btnClose.getScene().getWindow());

		Parent parent = null;

		try {
			parent = FXMLLoader.load(FindController.class.getResource("findID.fxml"));
		} catch (Exception e1) {

		}

		TextField textID1 = (TextField) parent.lookup("#textID1");
		TextField textNick1 = (TextField) parent.lookup("#textNick1");
		Button btnClose = (Button) parent.lookup("#btnClose");
		Button btnSuccess = (Button) parent.lookup("#btnSuccess");

		textNick1.setOnKeyPressed(key -> {
			if (key.getCode().equals(KeyCode.ENTER)) {
				Platform.runLater(() -> {
					btnSuccess.fire();
				});
			}
		});

		btnClose.setOnAction(event -> dialog.close());
		btnSuccess.setOnAction(event -> {
			if (textID1.getText().isEmpty()) {
				JOptionPane.showMessageDialog(null, "Mail을 입력해주세요.");
			} else if (textNick1.getText().isEmpty()) {
				JOptionPane.showMessageDialog(null, "NickName을 입력해주세요.");
			} else {
				main.btnIDReturn(textID1.getText() + "|" + textNick1.getText());
				dialog.close();
			}
		});

		System.out.println(textNick1.getText());
		Scene scene = new Scene(parent);

		dialog.setTitle("아이디 찾기 화면");
		dialog.setScene(scene);
		dialog.setResizable(false);
		dialog.show();
	}

	public void handleBtnPassword(ActionEvent e) {
		System.out.println("비밀번호 찾기");
		Stage dialog = new Stage(StageStyle.DECORATED);
		dialog.initModality(Modality.WINDOW_MODAL);
		dialog.initOwner(btnClose.getScene().getWindow());

		Parent parent = null;

		try {
			parent = FXMLLoader.load(FindController.class.getResource("findPw.fxml"));
		} catch (Exception e1) {
			System.out.println("비밀번호찾기 창 오류");

		}

		TextField textID2 = (TextField) parent.lookup("#textID2");
		TextField textMail2 = (TextField) parent.lookup("#textMail2");
		TextField textNick2 = (TextField) parent.lookup("#textNick2");
		Button btnClose2 = (Button) parent.lookup("#btnClose2");
		Button btnSuccess2 = (Button) parent.lookup("#btnSuccess2");
		

		textNick2.setOnKeyPressed(key -> {
			if (key.getCode().equals(KeyCode.ENTER)) {
				Platform.runLater(() -> {
					btnSuccess2.fire();
				});
			}
		});

		btnSuccess2.setOnAction(event -> {
			if (textID2.getText().isEmpty()) {
				JOptionPane.showMessageDialog(null, "ID을 입력해주세요.");
			} else if (textMail2.getText().isEmpty()) {
				JOptionPane.showMessageDialog(null, "Mail을 입력해주세요.");
			} else if (textNick2.getText().isEmpty()) {
				JOptionPane.showMessageDialog(null, "NickName을 입력해주세요.");
			} else {
				main.btnPwReturn(textID2.getText() + "|" + textMail2.getText() + "|" + textNick2.getText());
				dialog.close();
			}

		});
		btnClose2.setOnAction(event -> dialog.close());

		Scene scene = new Scene(parent);

		dialog.setTitle("비밀번호 찾기 화면");
		dialog.setScene(scene);
		dialog.setResizable(false);
		dialog.show();
	}

}
