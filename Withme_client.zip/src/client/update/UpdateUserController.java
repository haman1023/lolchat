package client.update;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import client.main.WaitingRoomController;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import vo.UserVO;

public class UpdateUserController implements Initializable {

	WaitingRoomController main;
	String pwd;
	boolean isChanged = false;
	public boolean isCheck = false;
	 private ObservableList<String> list = FXCollections.observableArrayList(
				"unRanked","Iron Ⅳ","Iron Ⅲ","Iron Ⅱ","Iron Ⅰ"
				,"Bronze Ⅳ","Bronze Ⅲ","Bronze Ⅱ","Bronze Ⅰ"
				,"Silver Ⅳ","Silver Ⅲ","Silver Ⅱ","Silver Ⅰ"
				,"Gold Ⅳ","Gold Ⅲ","Gold Ⅱ","Gold Ⅰ"
				,"Platinum Ⅳ","Platinum Ⅲ","Platinum Ⅱ","Platinum Ⅰ"
				,"Diamond Ⅳ","Diamond Ⅲ","Diamond Ⅱ","Diamond Ⅰ"
				,"Master","GrandMaster","Challenger");
	
	
	
	
	public UpdateUserController(WaitingRoomController main) {
		this.main = main;
		showUpdateDialog();
	}
	
	public void showUpdateDialog() {
		Stage dialog = new Stage(StageStyle.UTILITY);
		dialog.initModality(Modality.WINDOW_MODAL);
		dialog.initOwner(main.filter.getScene().getWindow());
		dialog.setTitle("정보 수정");
		
		Parent parent = null;
		try {
			parent = FXMLLoader.load(UpdateUserController.class.getResource("updateuser.fxml"));
		} catch (IOException e) {
			System.out.println("updateuser.fxml 불러오기 오류");
			main.stopClient();
		}
		TextField txtId = (TextField)parent.lookup("#txtID");
		TextField txtemail =(TextField)parent.lookup("#txtEmail");
		TextField txtLolID = (TextField)parent.lookup("#txtLolID");
		ComboBox combox1 = (ComboBox)parent.lookup("#combo_box");
		ComboBox combox2 = (ComboBox)parent.lookup("#combo_box2");
		Button btnOK = (Button)parent.lookup("#btnSuccess");
		Button btnCancel = (Button)parent.lookup("#btnClose");
		Button btnPwdChange = (Button)parent.lookup("#btnChangePwd");
		Button btnLolIDCheck = (Button)parent.lookup("#btnIdCheck");

		txtId.setText(main.getUserVO().getUserID());
		txtemail.setText(main.getUserVO().getEmail());
		txtLolID.setText(main.getUserVO().getLolID());
		combox1.setItems(list);
		combox2.setItems(list);
		
		String sol = main.getUserVO().getSoloRank();
		String free = main.getUserVO().getFreeRank();
		
		int sol_index = getTierIndex(sol);
		int free_index = getTierIndex(free);
		
		combox1.getSelectionModel().select(sol_index);
		combox2.getSelectionModel().select(free_index);

		btnPwdChange.setOnAction(e->{
			Stage dialog2 = new Stage(StageStyle.UTILITY);
			dialog2.initModality(Modality.WINDOW_MODAL);
			dialog2.initOwner(btnPwdChange.getScene().getWindow());
			dialog2.setTitle("비밀번호 수정");
			
			Parent p = null;
			try {
				p = FXMLLoader.load(UpdateUserController.class.getResource("passwordchange.fxml"));
			} catch (IOException e1) {
				main.stopClient();
				e1.printStackTrace();
			}
		
			TextField oldPwdText = (TextField)p.lookup("#oldPwdText");
			TextField newPwdText = (TextField)p.lookup("#newPwdText");
			TextField newPwdCheckText = (TextField)p.lookup("#newPwdCheckText");
			Button btnOk2 = (Button)p.lookup("#btnOK");
			Button btnCancel2 = (Button)p.lookup("#btnCancel");
			
			btnCancel2.setOnAction(event->{
			isChanged = false;	
			dialog2.close();
			});
			btnOk2.setOnAction(event->{
				String oldpwd = oldPwdText.getText();
				String newpwd = newPwdText.getText();
				String newpwdck = newPwdCheckText.getText();
				
				if(!oldpwd.equals(main.getUserVO().getPassword())) {
					Platform.runLater(()->{
						ShowErrMsg("비밀번호 확인","기존 비밀번호를 확인해주세요");
						oldPwdText.setText("");
					});
				}else {
					if(newpwd.equals(newpwdck)) {
						pwd = newpwd;
						isChanged = true;
						dialog2.close();
					}else {
						Platform.runLater(()->{
							ShowErrMsg("새 비밀번호 확인", "새 비밀번호가 일치하지 않습니다.");
							newPwdText.setText("");
							newPwdCheckText.setText("");
						});
					}
				}
				
			});
			
			Scene scene2 = new Scene(p);
			dialog2.setScene(scene2);
			dialog2.setResizable(false);
			dialog2.show();
			
		});
		
		btnLolIDCheck.setOnAction(e->{
			String lolId = txtLolID.getText();
			if(lolId.equals("")) {
				ShowErrMsg("롤 닉네임 확인","롤 닉네임을 입력해주세요");
				return;
			}
			if(main.getUserVO().getLolID().equals(lolId)) {
				isCheck = true;
				ShowErrMsg("롤 닉네임 확인","기존 닉네임을 사용합니다.");
				return;
			}
			else {
				main.handleLolIdDuplicateCheck(lolId);
			}
		});

		
		btnOK.setOnAction(e->{
			if(txtLolID.getText().equals("")) {
				ShowErrMsg("롤 닉네임 확인","롤 닉네임을 입력해주세요");
				return;
			}
			if(!isCheck) {
				ShowErrMsg("롤 닉네임 검사","롤 닉네임 중복확인을 해주세요");
				return;
			}
			UserVO newUser = main.getUserVO();
			newUser.setLolID(txtLolID.getText());
			newUser.setEmail(txtemail.getText());
			newUser.setSoloRank((String)combox1.getSelectionModel().getSelectedItem());
			newUser.setFreeRank((String)combox2.getSelectionModel().getSelectedItem());
			if(isChanged && pwd !=null) {
				newUser.setPassword(pwd);
			}
			main.updateUser(newUser);
			dialog.close();
		});
		
		
		btnCancel.setOnAction(e->{
			dialog.close();
		});
		
		
		Scene scene = new Scene(parent);
		dialog.setScene(scene);
		dialog.setResizable(false);
		dialog.show();
		
	}
	
	public int getTierIndex(String sol) {
		int index = -1;
		switch(sol) {
		case "unRanked":
			index = 0;
			break;
		case "Iron Ⅳ":
			index = 1;
			break;
		case "Iron Ⅲ":
			index = 2;
			break;
		case "Iron Ⅱ":
			index = 3;
			break;
		case "Iron Ⅰ":
			index = 4;
			break;
		case "Bronze Ⅳ":
			index = 5;
			break;
		case "Bronze Ⅲ":
			index = 6;
			break;
		case "Bronze Ⅱ":
			index = 7;
			break;
		case "Bronze Ⅰ":
			index = 8;
			break;
		case "Silver Ⅳ":
			index = 9;
			break;
		case "Silver Ⅲ":
			index = 10;
			break;
		case "Silver Ⅱ":
			index = 11;
			break;
		case "Silver Ⅰ":
			index = 12;
			break;
		case "Gold Ⅳ":
			index = 13;
			break;
		case "Gold Ⅲ":
			index = 14;
			break;
		case "Gold Ⅱ":
			index = 15;
			break;
		case "Gold Ⅰ":
			index = 16;
			break;
		case "Platinum Ⅳ":
			index = 17;
			break;
		case "Platinum Ⅲ":
			index = 18;
			break;
		case "Platinum Ⅱ":
			index = 19;
			break;
		case "Platinum Ⅰ":
			index = 20;
			break;
		case "Diamond Ⅳ":
			index = 21;
			break;
		case "Diamond Ⅲ":
			index = 22;
			break;
		case "Diamond Ⅱ":
			index = 23;
			break;
		case "Diamond Ⅰ":
			index = 24;
			break;
		case "Master":
			index = 25;
			break;
		case "GrandMaster":
			index = 26;
			break;
		case "Challenger":
			index = 27;
			break;
			
		}
		return index;
	}
	
	public void ShowErrMsg(String title, String content) {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(content);
		alert.showAndWait();
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}
}
