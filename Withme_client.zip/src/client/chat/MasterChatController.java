package client.chat;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;

import client.main.WaitingRoomController;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import vo.MessageVO;
import vo.RoomVO;
import vo.UserVO;

public class MasterChatController{
	
	private Button btnSend, btnKick, btnRemoveRoom;
	private TextField txtInput;
	private TextArea txtDisplay;
	private ListView<UserVO> userListView;

	WaitingRoomController main;	//	main정보
	ObservableList<UserVO> roomList;

//	Socket socket;		//	소켓
	RoomVO room;	//	자신이 접속한 룸의 정보

	//	생성자에서 main컨트롤러를 받아온다.
	public MasterChatController(WaitingRoomController main, RoomVO room){
		this.main = main;
		this.room = room;
		showMasterChatRoom();
	}

	//	Dialog 실행
	private void showMasterChatRoom() {
		System.out.println("마스터 채팅방 접속하기");
		
		Stage chattingRoom = new Stage(StageStyle.UTILITY);
		chattingRoom.initModality(Modality.WINDOW_MODAL);
		chattingRoom.initOwner(main.filter.getScene().getWindow());
		chattingRoom.setTitle(room.getRoomNumber()+"번방");

		//chattingRoom.setTitle(main.room.getRoomNumber() + "번 채팅방");

		FXMLLoader loader = null;
		Parent chat = null;
		
		try {
			loader = new FXMLLoader(getClass().getResource("master_chat.fxml"));
			chat = loader.load();
		} catch (IOException e) {
			System.out.println("master_chat.fxml 로딩 오류");
		}
		
		btnSend = (Button)chat.lookup("#btnSend");
		btnRemoveRoom = (Button)chat.lookup("#btnRemoveRoom");
		btnKick = (Button)chat.lookup("#btnKick");
		txtInput = (TextField)chat.lookup("#txtInput");
		txtDisplay = (TextArea)chat.lookup("#txtDisplay");
		userListView = (ListView<UserVO>)chat.lookup("#userListView");
		
		Scene scene = new Scene(chat);
		chattingRoom.setOnCloseRequest(event->removeRoom());
		chattingRoom.setScene(scene);
		chattingRoom.setResizable(false);
		chattingRoom.show();
		
		//	보내기 버튼 클릭
		btnSend.setOnAction(event->send(txtInput.getText()));
		
		//	입력창에서 엔터
		txtInput.setOnKeyPressed(key->{
			if(key.getCode().equals(KeyCode.ENTER)) {
				btnSend.fire();
				txtInput.requestFocus();
			}
		});
		
		//	방에서 나가기 버튼 클릭
		btnRemoveRoom.setOnAction(event->{
			if(roomList.size()>1) {
				Platform.runLater(()->displayText("유저가 남아있으면 나갈 수 없습니다."));
			}else {
				removeRoom();
			}
		});
		
		//	강퇴 버튼 클릭
		btnKick.setOnAction(event->{
			kickUser(userListView);
		});
		
		userListView.setOnMouseClicked(event->{
			if(btnKick.isDisabled()) {
				btnKick.setDisable(false);
			}
			
			if(event.getClickCount()>1) {
				try {
					UserVO selectedUser = userListView.getSelectionModel().getSelectedItem();
					String url = "https://www.op.gg/summoner/userName=" + selectedUser.getLolID();
					Desktop.getDesktop().browse(new URI(url));
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println("오피지지 오류");
				}
			}
		});
	}

	//	23: 서버에 메세지 보내기
	public void send(String message) {
		main.sendMessage(message);
		Platform.runLater(()->txtInput.clear());
	}
	
	//	23: 서버에서 메세지 받기
	public void recieve(MessageVO data) {
		switch(data.getCode()) {
			case 23:	//	메세지 받기
				Platform.runLater(()->displayText((String)data.getMessge()));
				break;
			case 24:	//	유저리스트 그리기
				drawUserList((RoomVO)data.getMessge());
				break;
			case 25:
				break;
		}
	}

	//	23: 채팅창에 메세지 뿌리기
	private void displayText(String data) {
		txtDisplay.appendText(data+"\n");
	}
	
	//	24: 유저리스트 그리기
	private void drawUserList(RoomVO data) {
		Platform.runLater(()-> {
			roomList = FXCollections.observableArrayList();
			roomList.addAll(data.getUserList());
			userListView.setItems(roomList);
		});
	}
	
	//	25: 유저 강퇴
	private void kickUser(ListView<UserVO> userListView) {
		UserVO kickUserVO = userListView.getSelectionModel().getSelectedItem();
		if(userListView.getSelectionModel().getSelectedIndex() == 0) {
			Platform.runLater(()->displayText("자기 자신은 강퇴 시킬 수 없습니다."));
		}else {
			main.kickUser(kickUserVO);
		}
	}

	//	26: 룸마스터 채팅방 퇴장
	public void removeRoom() {
		Stage userChat = (Stage)btnRemoveRoom.getScene().getWindow();
		userChat.close();

		main.exitRoom(room);
//		main.exitRoomMaster(room);	//	main 컨트롤러의 exitRoom 메소드 호출
	}
}
