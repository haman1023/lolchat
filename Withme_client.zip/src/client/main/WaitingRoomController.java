package client.main;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Vector;

import javax.swing.JOptionPane;

import client.chat.MasterChatController;
import client.chat.UserChatController;
import client.login.LoginController;
import client.update.UpdateUserController;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import vo.MessageVO;
import vo.RoomVO;
import vo.UserVO;

//버튼부터 

public class WaitingRoomController implements Initializable {

	public static final String SERVER_IP = "192.168.1.4";
	public static final int SERVER_PORT = 5001;
	private UserVO user = new UserVO();
	private Stage primaryStage;

	RoomVO currentRoom = null;
	
	@FXML
	public ComboBox<String> filter;
	@FXML
	private Button btnUpdateUser, btnCreateRoom, btnRefresh, btnSearch, btnBefore, btnNext;

	// 동적 추가할 대상 박스들
	@FXML
	HBox mainHbox;
	@FXML
	VBox vboxLeft, vboxRight;
	@FXML
	TextField txtSearchRoom;
	@FXML
	Label lblPage,lolIDLbl;
	private boolean toggle = true;

	ObservableList<String> comboList = FXCollections.observableArrayList("전체", "2인랭", "자유랭", "일반", "칼바람"); // 필터(콤보박스)
																											// 리스트

	List<RoomVO> showList = new ArrayList<>(); // 서버로부터 받는 리스트
	List<RoomVO> filterList; // 필터 후 리스트

	boolean isfilter = false;
	boolean isSocketOn = false;
	boolean isId = false;
	boolean isLolId = false;


	int totalPage = 1; // 페이징 변수
	int currentPage = 1;
	int position = -1; // 포지션

	UserChatController controller;
	MasterChatController masterController;
	LoginController loginController;
	UpdateUserController updateUserController;

	Socket socket;

	InputStream is;
	OutputStream os;
	ObjectInputStream ois;
	ObjectOutputStream oos;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

		// 필터 세팅
		filter.setItems(comboList);
		filter.getSelectionModel().selectFirst();
		filter.setOnAction(event -> {
			filterList = new ArrayList<>();
			int value = filter.getSelectionModel().getSelectedIndex();
			if (value == 0) {
				filterList = showList;
			} else {
				for (RoomVO rvo : showList) {
					if (rvo.getRoomType() == (value - 1))
						filterList.add(rvo);
				}
			}

			setTotalPage(filterList);
			currentPage = 1;
			if (totalPage > 1) {
				Platform.runLater(() -> {
					btnNext.setDisable(false);
					btnBefore.setDisable(true);
				});

			} else {
				Platform.runLater(() -> {
					btnNext.setDisable(true);
					btnBefore.setDisable(true);
				});
			}
			showRoomList(filterList);
			isfilter = true;

		});

		txtSearchRoom.setOnKeyPressed(key -> {
			if (key.getCode().equals(KeyCode.ENTER)) {
				btnSearch.fire();
			}
		});

		//
		btnBefore.setDisable(true);
		btnNext.setDisable(true);

		// 버튼 이벤트
		btnCreateRoom.setOnAction(event -> handleBtnCreateRoom(event));
		btnRefresh.setOnAction(event -> handleBtnRefresh(event));
		btnSearch.setOnAction(event -> handleBtnSearchRoom(event));
		btnBefore.setOnAction(event -> handleBtnBefore(event));
		btnNext.setOnAction(event -> handleBtnNext(event));
		btnUpdateUser.setOnAction(event -> handleBtnUpdateUser(event));

		// 중간 showBox 초기화
		vboxLeft.setPadding(new Insets(10, 10, 10, 10));
		vboxLeft.setSpacing(10);
		vboxRight.setPadding(new Insets(10, 10, 10, 10));
		vboxRight.setSpacing(10);

		// roomList 서버로부터 받는 부분
		startClient();
		
		MessageVO message = new MessageVO(31, ""); // 전체리스트 받아옴
		send(message);

		Platform.runLater(() -> {
			if (showList.size() > 8)
				btnNext.setDisable(false);
		});
		showRoomList(showList);
		
		Platform.runLater(() -> {
			loginController = new LoginController(this);
		});
	}

	// Before 버튼 이벤트함수
	public void handleBtnBefore(ActionEvent e) {
		Platform.runLater(() -> btnNext.setDisable(false));
		currentPage--;
		if (currentPage == 1) {
			Platform.runLater(() -> btnBefore.setDisable(true));
		}
		if (isfilter) {
			showRoomList(filterList);
		} else {
			showRoomList(showList);
		}

	}

	// Next 버튼 이벤트 함수
	public void handleBtnNext(ActionEvent e) {
		Platform.runLater(() -> btnBefore.setDisable(false));
		currentPage++;
		if (currentPage == totalPage) {
			Platform.runLater(() -> btnNext.setDisable(true));
		}
		if (isfilter) {
			showRoomList(filterList);
		} else {
			showRoomList(showList);
		}
	}

	// list받아서 화면에 뿌려주는 함수.
	public void showRoomList(List<RoomVO> roomlist) {
		listClear(); // 초기화(목록 없애기)

		int start = (currentPage - 1) * 8; // 시작
		int end = currentPage * 8; // 마지막
		if (roomlist.size() <= 8) { // 1페이지일 경우 리스트 사이즈가 end로 설정
			end = roomlist.size();
		}
		if (currentPage == totalPage) { // 마지막 페이지 경우 리스트 사이즈가 end로 설정
			end = roomlist.size();
		}

		for (int i = start; i < end; i++) {
			try {
				// 리스트 구성(방 하나)
				FXMLLoader loader = new FXMLLoader(getClass().getResource("chatroom.fxml"));
				Parent parent = loader.load();
				HBox newBox = (HBox) parent.lookup("#mainHbox");
				Label lbl = (Label) parent.lookup("#roomTypeLbl");
				Label title = (Label) parent.lookup("#title");
				Label own = (Label) parent.lookup("#own");
				Button btnTop = (Button) parent.lookup("#Top");
				Button btnJungle = (Button) parent.lookup("#Jungle");
				Button btnMid = (Button) parent.lookup("#Mid");
				Button btnAD = (Button) parent.lookup("#AD");
				Button btnSupport = (Button) parent.lookup("#Support");
				//
				Image imageTop = new Image(getClass().getResourceAsStream("../image/top1.png"));
				ImageView imageViewTop = new ImageView(imageTop);
				imageViewTop.setFitHeight(40.0);
				imageViewTop.setFitWidth(40.0);
				btnTop.setGraphic(imageViewTop);

				Image imageJungle = new Image(getClass().getResourceAsStream("../image/jungle1.png"));
				ImageView imageViewJungle = new ImageView(imageJungle);
				imageViewJungle.setFitHeight(40.0);
				imageViewJungle.setFitWidth(40.0);
				btnJungle.setGraphic(imageViewJungle);

				Image imageMid = new Image(getClass().getResourceAsStream("../image/mid1.png"));
				ImageView imageViewMid = new ImageView(imageMid);
				imageViewMid.setFitHeight(40.0);
				imageViewMid.setFitWidth(40.0);
				btnMid.setGraphic(imageViewMid);

				Image imageAD = new Image(getClass().getResourceAsStream("../image/bottom1.png"));
				ImageView imageViewAD = new ImageView(imageAD);
				imageViewAD.setFitHeight(40.0);
				imageViewAD.setFitWidth(40.0);
				btnAD.setGraphic(imageViewAD);

				Image imageSup = new Image(getClass().getResourceAsStream("../image/support1.png"));
				ImageView imageViewSup = new ImageView(imageSup);
				imageViewSup.setFitHeight(40.0);
				imageViewSup.setFitWidth(40.0);
				btnSupport.setGraphic(imageViewSup);

				btnTop.setOnAction((e) -> {
					position = 1;
				});

				btnJungle.setOnAction((e) -> {
					position = 2;
				});
				btnMid.setOnAction((e) -> {
					position = 3;
				});
				btnAD.setOnAction((e) -> {
					position = 4;
				});
				btnSupport.setOnAction((e) -> {
					position = 5;
				});

				// 포지션 버튼 설정
				btnTop.setDisable(false);
				btnJungle.setDisable(false);
				btnMid.setDisable(false);
				btnAD.setDisable(false);
				btnSupport.setDisable(false);
				boolean position[] = roomlist.get(i).getPosition();
				if (position[0] == true) {
					btnTop.setDisable(true);
					Image imageTop2 = new Image(getClass().getResourceAsStream("../image/top2.png"));
					ImageView imageViewTop2 = new ImageView(imageTop2);
					imageViewTop2.setFitHeight(40.0);
					imageViewTop2.setFitWidth(40.0);
					btnTop.setGraphic(imageViewTop2);
					btnTop.setStyle("-fx-opacity: 0.6");
				}
				if (position[1] == true) {
					btnJungle.setDisable(true);
					Image imageJungle2 = new Image(getClass().getResourceAsStream("../image/jungle2.png"));
					ImageView imageViewJungle2 = new ImageView(imageJungle2);
					imageViewJungle2.setFitHeight(40.0);
					imageViewJungle2.setFitWidth(40.0);
					btnJungle.setGraphic(imageViewJungle2);
					btnJungle.setStyle("-fx-opacity: 0.6");
				}
				if (position[2] == true) {
					btnMid.setDisable(true);
					Image imageMid2 = new Image(getClass().getResourceAsStream("../image/mid2.png"));
					ImageView imageViewMid2 = new ImageView(imageMid2);
					imageViewMid2.setFitHeight(40.0);
					imageViewMid2.setFitWidth(40.0);
					btnMid.setGraphic(imageViewMid2);
					btnMid.setStyle("-fx-opacity: 0.6");
				}
				if (position[3] == true) {
					btnAD.setDisable(true);
					Image imageAD2 = new Image(getClass().getResourceAsStream("../image/bottom2.png"));
					ImageView imageViewAD2 = new ImageView(imageAD2);
					imageViewAD2.setFitHeight(40.0);
					imageViewAD2.setFitWidth(40.0);
					btnAD.setGraphic(imageViewAD2);
					btnAD.setStyle("-fx-opacity: 0.6");
				}
				if (position[4] == true) {
					btnSupport.setDisable(true);
					Image imageSup2 = new Image(getClass().getResourceAsStream("../image/support2.png"));
					ImageView imageViewSup2 = new ImageView(imageSup2);
					imageViewSup2.setFitHeight(40.0);
					imageViewSup2.setFitWidth(40.0);
					btnSupport.setGraphic(imageViewSup2);
					btnSupport.setStyle("-fx-opacity: 0.6");
				}

				// 입장 버튼 설정
				Button btnEnter = new Button();
				btnEnter = (Button) parent.lookup("#btnEnter");
				btnEnter.setId("btnEnter" + i);
				// 입장제한수와 현재입장인원사이즈 비교해서 버튼 활성/비활성
				if (roomlist.get(i).getLimit() == roomlist.get(i).getUserList().size()) {
					btnEnter.setDisable(true);
				}

				// 입장버튼 이벤트 함수
				RoomVO r = roomlist.get(i);
				btnEnter.setOnAction(event -> {

					if (this.position == -1) {
						Platform.runLater(() -> {
							Alert alert = new Alert(AlertType.INFORMATION);
							alert.setTitle("포지션 선택");
							alert.setHeaderText(null);
							alert.setContentText("포지션을 선택해주세요.");
							alert.showAndWait();
						});
						return;
					}
					enterRoom(r);
				});

				// 방 타입
				switch (roomlist.get(i).getRoomType()) {
				case 0:
					lbl.setText("2인랭");
					break;
				case 1:
					lbl.setText("자유랭");
					break;
				case 2:
					lbl.setText("일반");
					break;
				case 3:
					lbl.setText("칼바람");
					break;
				}
				title.setText(roomlist.get(i).getTitle() + " (" + roomlist.get(i).getUserList().size() + "/"
						+ roomlist.get(i).getLimit() + ")    (티어 : " + roomlist.get(i).getTier() + ")");
				own.setText(roomlist.get(i).getMasterUser().getLolID());

				newBox.setStyle("-fx-border-color:gray");

				// 토글이용, 좌, 우 번갈아 뿌려줌
				if (toggle) {
					vboxLeft.getChildren().add(newBox);
					toggle = false;
				} else {
					vboxRight.getChildren().add(newBox);
					toggle = true;
				}

			} catch (IOException e1) {
				System.out.println("리스트 뿌려주기 오류");
				stopClient();
			}
		}
	}

	// 21 : 채팅방 접속
	public void enterRoom(RoomVO room) {

		System.out.println(room);

		if (user.getLolID().equals(room.getMasterUser().getLolID())) {
			masterController = new MasterChatController(this, room);
		} else {
			controller = new UserChatController(this, room);
			room.setEnterPosition(position);
			System.out.println(room);
		}

		currentRoom = room;

		MessageVO<RoomVO> data = new MessageVO<>(21, room); // 21 : 채팅방 입장
		send(data);
	}

	// 22: 채팅방 퇴장
	public void exitRoom(RoomVO room) {
		System.out.println("채팅방 퇴장");
		System.out.println("방퇴장 포지션" + position);
		room.setExitPosition(position);
		MessageVO<RoomVO> data = new MessageVO<>(22, room); // 22 : 채팅방 퇴장
		send(data);
		currentRoom = null;
		position = -1;
	}

	// 23: 메세지 보내기
	public void sendMessage(String message) {
		System.out.println("메세지 보내기");
		
		switch(position) {
			case 1:
				message = "(Top) "+message;
				break;
			case 2:
				message = "(Jgl) "+message;
				break;
			case 3:
				message = "(Mid) "+message;
				break;
			case 4:
				message = "(AD) "+message;
				break;
			case 5:
				message = "(Sup) "+message;
				break;
		}

		MessageVO<String> data = new MessageVO<>(23, message); // 23: 메세지 보내기
		send(data);
	}

	// 25: 유저 강퇴
	public void kickUser(UserVO kickUserVO) {
		System.out.println("유저 강퇴");

		MessageVO<UserVO> data = new MessageVO<>(25, kickUserVO); // 23: 메세지 보내기
		send(data);
	}

	// 25: 강퇴 당함
	private void kick() {
		System.out.println("강퇴 당함");

		Platform.runLater(() -> {
			controller.exitUser();

			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("강퇴당함");
			alert.setHeaderText(null);
			alert.setContentText("방장에 의해 강퇴되었습니다.");
			alert.showAndWait();
		});
	}

	// 26: 룸마스터 채팅방 퇴장
	public void exitRoomMaster(RoomVO room) {
		MessageVO<RoomVO> data = new MessageVO<>(26, room); // 26 : 룸마스터 채팅방 퇴장
		send(data);
		currentRoom = null;
	}

	// 유저정보 수정
	public void handleBtnUpdateUser(ActionEvent e) {
		updateUserController = new UpdateUserController(this);
	}

	// 11 : 방생성 버튼 클릭
	public void handleBtnCreateRoom(ActionEvent e) {
		Stage dialog = new Stage(StageStyle.UTILITY);
		dialog.initModality(Modality.WINDOW_MODAL);
		dialog.initOwner(primaryStage);
		dialog.setTitle("방 생성");
		Parent root = null;

		try {
			root = FXMLLoader.load(getClass().getResource("createroom.fxml"));
		} catch (IOException e1) {
			System.out.println("createroom.fxml 불러오기 오류");
			stopClient();
		}

		TextField title = (TextField) root.lookup("#title");
		ComboBox<String> partyType = (ComboBox<String>) root.lookup("#cbxPartyType");
		ComboBox<String> position = (ComboBox<String>) root.lookup("#cbxPosition");
		ComboBox<String> tier = (ComboBox<String>) root.lookup("#hopeTier");
		ComboBox<String> enterLimit = (ComboBox<String>) root.lookup("#cbxMember");
//		PasswordField pwd = (PasswordField) root.lookup("#passField");
		Button btnCreate = (Button) root.lookup("#btnCreate");

		partyType.getSelectionModel().selectFirst();
		position.getSelectionModel().selectFirst();
		tier.getSelectionModel().selectFirst();

		enterLimit.getSelectionModel().selectFirst();

		btnCreate.setOnAction(event -> {
			String titles = title.getText();
			int type = 0;
			int positioni = 0;
			switch (partyType.getValue()) {
				case "일반":
					type = 2;
					break;
				case "2인랭":
					type = 0;
					break;
				case "자유랭":
					type = 1;
					break;
				case "칼바람":
					type = 3;
					break;
			}
			switch (position.getValue()) {
				case "Top":
					positioni = 0;
					break;
				case "Jungle":
					positioni = 1;
					break;
				case "Mid":
					positioni = 2;
					break;
				case "BottAD":
					positioni = 3;
					break;
				case "Sup":
					positioni = 4;
					break;
			}
			
			WaitingRoomController.this.position = positioni + 1;

			boolean isDuplicateNumber = false;
			int number = 0;

			// 방번호 랜덤으로 출력
			repeat: while (!isDuplicateNumber) {
				number = (int) (Math.random() * 10000000);
				for (int i = 0; i < showList.size(); i++) {
					if (showList.get(i).getRoomNumber() == number) {
						continue repeat;
					}
				}
				break;
			}

			if (!titles.isEmpty()) {
				RoomVO rvo = new RoomVO(number, type, titles, user, positioni, Integer.parseInt(enterLimit.getValue()));
				rvo.setTier(tier.getValue());

//				rvo.setPassword(pwd.getText());
				MessageVO mvo = new MessageVO(11, rvo);
				send(mvo);

				dialog.close();
				enterRoom(rvo);
			}
		});
		Scene scene = new Scene(root);
		dialog.setScene(scene);
		dialog.show();
	}

	// 새로고침(리셋)
	public void handleBtnRefresh(ActionEvent e) {
		filter.getSelectionModel().selectFirst();
		txtSearchRoom.clear();
		MessageVO mvo = new MessageVO(31, "");
		send(mvo);
		isfilter = false;
	}

	// 리스트 초기화
	public void listClear() {
		while (true) {
			if (!vboxLeft.getChildren().isEmpty()) {
				vboxLeft.getChildren().remove(0);
			} else if (!vboxRight.getChildren().isEmpty()) {
				vboxRight.getChildren().remove(0);
			} else {
				break;
			}
		}
		toggle = true;
	}

	// 방 검색
	public void handleBtnSearchRoom(ActionEvent e) {
		String message = "";
		String targetText = txtSearchRoom.getText();

		if (targetText == "")
			return;

		message = targetText;

		MessageVO mvo = new MessageVO(35, message);
		send(mvo);
		txtSearchRoom.clear();
	}

	//클라이언트 서버 접속
	public void startClient() {
		try {
			socket = new Socket(SERVER_IP, SERVER_PORT);
			isSocketOn = true;
			receive();
		} catch (Exception e) {
			stopClient();
		}

	}

	//클라이언트 종료
	public void stopClient() {
		try {
			isSocketOn = false;
			if (socket != null && !socket.isClosed()) {
				socket.close();
			}
		} catch (IOException e) {
		}
	}

	//리시브
	public void receive() {
		new Thread(() -> {
			while (isSocketOn) {
				try {
					ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
					MessageVO mvo = (MessageVO) ois.readObject();
					System.out.println("서버로부터 받음 " + mvo.getCode());

					switch (mvo.getCode()) {
					case 1: // 회원가입 확인
						boolean isSignUp = ((boolean) mvo.getMessge());
						System.out.println("회원가입 확인 : " + mvo.getMessge());
						if (isSignUp) {
							JOptionPane.showMessageDialog(null, "회원 가입이 완료 되었습니다.");
						} else {
							JOptionPane.showMessageDialog(null, "회원 가입이 실패 했습니다.");
						}
						break;
					case 2: // 아이디 중복 확인
						boolean idCheck = ((boolean) mvo.getMessge());
						System.out.println("확인 아이디" + mvo.getMessge());
						if (idCheck == false) {
							JOptionPane.showMessageDialog(null, "중복된 아이디입니다.");
							isId = false;
						} else {
							JOptionPane.showMessageDialog(null, "사용 가능합니다.");
							isId = true;
//							idCheckbtn(isId);

						}
						break;
					case 3: // 가입된 아이디 뿌려주기
						String idReturn = ((String) mvo.getMessge());
						System.out.println("확인 아이디" + mvo.getMessge());
						if (idReturn.isEmpty()) {
							JOptionPane.showMessageDialog(null, "등록된 회원정보가 없습니다.");
						} else {
							JOptionPane.showMessageDialog(null, "입력하신 회원님의 아이디는 : " + idReturn + "입니다.");
						}
						break;

					case 4: // 가입된 비밀번호 뿌려주기
						String pwReturn = ((String) mvo.getMessge());
						System.out.println("확인된 비밀번호는" + pwReturn);
						if (!pwReturn.isEmpty()) {
							JOptionPane.showMessageDialog(null, "입력하신 회원님의 비밀번호는 : " + pwReturn + "입니다.");
						} else {
							JOptionPane.showMessageDialog(null, "등록된 회원정보가 없습니다.");
						}
						break;
					case 5:
						user = (UserVO) mvo.getMessge();
						Platform.runLater(() ->{ 
							loginController.receiveLoginOK();
							lolIDLbl.setText("소환사명 : "+user.getLolID());
						});
						
						break;
					case 6: // 닉넹미 중복확인
						boolean nick = ((boolean) mvo.getMessge());
						System.out.println("확인 아이디" + mvo.getMessge());
						if (nick == false) {
							JOptionPane.showMessageDialog(null, "중복된 닉네임입니다.");
							isLolId = false;
						} else {
							JOptionPane.showMessageDialog(null, "사용 가능합니다.");
							isLolId = true;
						}
						break;
						
					case 12: // 정보수정, 롤아이디 체크 서버 응답
						boolean existLolID = (boolean) mvo.getMessge();
						alertResultCheckLolID(existLolID);
						break;
						
					case 13: // 정보수정에 대한 서버 응답
						boolean isUpdate = (boolean) mvo.getMessge();
						alertResultUpdate(isUpdate);
						break;
						
					case 14:
						Platform.runLater(() -> loginController.receiveLoginFail());
						break;
					case 15:
						Platform.runLater(() -> loginController.reveiveLoginDuplicate());
						break;
					case 23: // 메세지 받기
					case 24: // 유저리스트 그리기
						if ((currentRoom != null) && (user.getLolID().equals(currentRoom.getMasterUser().getLolID()))) {
							masterController.recieve(mvo);
						} else {
							controller.recieve(mvo);
						}
						break;

					case 25: // 유저리스트 그리기
						kick();
						break;

					case 31: // 요청리스트 받음
						showList = (List<RoomVO>) mvo.getMessge();
						System.out.println(showList.size());
						Platform.runLater(() -> {
							showRoomList(showList);
						});
						break;

					case 33: // 방생성 후 서버로부터 갱신된 리스트 받음
						if (mvo.getMessge() instanceof List) {
							showList = (Vector<RoomVO>) mvo.getMessge();
							System.out.println(showList.size());
							Platform.runLater(() -> {
								showRoomList(showList);
							});
						}
						break;
					case 34: // 방 입장 부분
						showList = (List<RoomVO>) mvo.getMessge();
						Platform.runLater(() -> {
							showRoomList(showList);
						});
						// 다이얼로그
						// 여기또는 위에서 처리.
						// ----------
						break;
					}

					// 페이징에 필요 부분
					setTotalPage();
					currentPage = 1;
					isfilter = false;
					if (totalPage > 1) {
						Platform.runLater(() -> btnNext.setDisable(false));
					} else {
						Platform.runLater(() -> btnNext.setDisable(true));
					}

				} catch (Exception e) {
					System.out.println("리시브 오류");
					e.printStackTrace();
					stopClient();

				}

			}
		}).start();
	}

	//서버로 메시지 보내기
	public void send(MessageVO message) {
		try {
			System.out.println(message);
			ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
			oos.writeObject(message);
			oos.flush();

		} catch (IOException e) {
			System.out.println("센드 오류");
			e.printStackTrace();
			stopClient();
		}
	}

	// 전체 페이지 계산
	public void setTotalPage(List<RoomVO> list) {
		if (list.size() == 0) {
			totalPage = 1;
			return;
		}
		if (list.size() % 8 != 0) {
			totalPage = (list.size() / 8) + 1;
			System.out.println();
		} else {
			totalPage = list.size() / 8;
		}
	}

	// 전체 페이지 계산2
	public void setTotalPage() {
		if (showList.size() == 0) {
			totalPage = 1;
			return;
		}
		if (showList.size() % 8 != 0) {
			totalPage = (showList.size() / 8) + 1;
			System.out.println();
		} else {
			totalPage = showList.size() / 8;
		}
	}

	public void setPrimaryStage(Stage primaryStage) {
		this.primaryStage = primaryStage;
	}

	
	//----로그인
	
	public void handleLogin(String message) {
		MessageVO mvo = new MessageVO(5, message);
		send(mvo);
	}
	// ----정보수정 형진
	public UserVO getUserVO() {
		return this.user;
	}
	
	//12 :수정때 롤id 중복체크
	public void handleLolIdDuplicateCheck(String id) {
		MessageVO mvo = new MessageVO(12, id);
		send(mvo);
	}
	
	//13 : 수정해라 
	public void updateUser(UserVO newUser) {
		MessageVO mvo = new MessageVO(13, newUser);
		send(mvo);
	}
	
	// 롤id 중복 경고 메시지
	public void alertResultCheckLolID(boolean exist) {
		updateUserController.isCheck = true;
		if (exist) {
			Platform.runLater(() -> {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("중복체크 결과");
				alert.setHeaderText(null);
				alert.setContentText("사용가능한 닉네임입니다.");
				alert.showAndWait();
	
			});
		} else {
			Platform.runLater(() -> {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("중복체크 결과");
				alert.setHeaderText(null);
				alert.setContentText("중복된 닉네임 입니다..");
				alert.showAndWait();
			});
		}
	}
	
	// 수정 결과에 대한 메시지 출력
	public void alertResultUpdate(boolean isUpdate) {
		if (isUpdate) {
			Platform.runLater(() -> {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("정보수정 결과");
				alert.setHeaderText(null);
				alert.setContentText("수정이 완료되었습니다.");
				alert.showAndWait();
				lolIDLbl.setText("소환사명 : "+user.getLolID());
			});
		} else {
			Platform.runLater(() -> {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("정보수정 결과");
				alert.setHeaderText(null);
				alert.setContentText("수정하지 못하였습니다.");
				alert.showAndWait();
			});
		}
	}

	//-----------------현우
	// 1: 회원가입
	public void signUp(UserVO user) {
		if (!isId) {
			JOptionPane.showMessageDialog(null, "중복된 아이디가 존재하므로 가입할 수 없습니다.");
		} else if (!isLolId) {
			JOptionPane.showMessageDialog(null, "중복된 롤아이디가 존재하므로 가입할 수 없습니다.");
		} else {
			MessageVO mvo = new MessageVO(1, user);
			send(mvo);
		}
	}

	// 2: 아이디 중복확인
	public void btnIDCheck(String userID) {
		MessageVO mvo = new MessageVO(2, userID);
		send(mvo);
	}

	// 3: 아이디 찾기
	public void btnIDReturn(String idSearch) {
		MessageVO mvo = new MessageVO(3, idSearch);
		send(mvo);

	}

	// 4: 비밀번호 찾기
	public void btnPwReturn(String pwSearch) {
		MessageVO mvo = new MessageVO(4, pwSearch);
		send(mvo);
	}

	// 6: 롤 닉네임 찾기
	public void btnNickCheck(String nickCheck) {
		MessageVO mvo = new MessageVO(6, nickCheck);
		send(mvo);
	}
}
