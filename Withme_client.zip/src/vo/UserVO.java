package vo;

import java.io.Serializable;

public class UserVO implements Serializable{
	
	private static final long serialVersionUID = 50L;
	
	private String userID;
	private String password;
	private String email;
	private String lolID;
	private String soloRank;
	private String freeRank;
	
	//	Test용
	public UserVO() {
		super();
	}

	public UserVO(String userID, String password, String email, String lolID, String soloRank, String freeRank) {
		this.userID = userID;
		this.password = password;
		this.email = email;
		this.lolID = lolID;
		this.soloRank = soloRank;
		this.freeRank = freeRank;
	}

	public String getUserID() {
		return userID;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getLolID() {
		return lolID;
	}

	public void setLolID(String lolID) {
		this.lolID = lolID;
	}

	public String getSoloRank() {
		return soloRank;
	}

	public void setSoloRank(String soloRank) {
		this.soloRank = soloRank;
	}

	public String getFreeRank() {
		return freeRank;
	}

	public void setFreeRank(String freeRank) {
		this.freeRank = freeRank;
	}
	
	@Override
	public String toString() {
		return lolID+"\n"+soloRank;
	}
}
