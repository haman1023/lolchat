package server.db.utill;

import vo.UserVO;

public interface UserDAO {
	
	public boolean insert(UserVO userVO);
	public UserVO Select(String id, String pwd);
	public boolean NickCheck(String lolID);
	public boolean updateUser(UserVO userVO);
	String pwReturn(String searchPw);
	boolean idCheck(String userID);
	String idReturn(String lolID);
}
