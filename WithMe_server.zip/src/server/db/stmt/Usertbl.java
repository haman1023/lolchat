package server.db.stmt;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import server.db.utill.DBHelper;
import server.db.utill.UserDAO;
import vo.UserVO;

public class Usertbl implements UserDAO {
	
	// DB 연결정보
		private Connection conn;
		// DB 질의 전송
		private Statement stmt= null;
		// DB 질의 결과값 
		private ResultSet rs;
		
		@Override
		public boolean insert(UserVO userVO) {
			System.out.println(userVO);
			int result = 0;

			conn = DBHelper.getConnection();
			try {
				stmt = conn.createStatement();

				String query = "INSERT INTO usertbl" + " VALUES('" + userVO.getUserID() + "'," + "'" + userVO.getPassword()
						+ "'," + "'" + userVO.getEmail() + "'," + "'" + userVO.getLolID() + "'," + "'"
						+ userVO.getSoloRank() + "'," + "'" + userVO.getFreeRank() + "');";
				System.out.println(query);
				result = stmt.executeUpdate(query);
				System.out.println(result);

			} catch (SQLException e) {
				System.out.println("Insert 오류  : " + e.getMessage());
				return false;
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
				} catch (SQLException e) {
				}
			}
			return true;
		}
		
		
		@Override
		public UserVO Select(String id, String pwd) {
			UserVO user = null;
			int  result = 0;

			conn = DBHelper.getConnection();
			
			try {
				stmt = conn.createStatement();
				String query = "SELECT * FROM usertbl WHERE userID = '"+id+"' and password ='"+pwd+"'";
				rs = stmt.executeQuery(query);
				while(rs.next()) {
					String userid = rs.getString(1);
					String password = rs.getString(2);
					String email = rs.getString(3);
					String lolID = rs.getString(4);
					String soloRank = rs.getString(5);
					String freeRank = rs.getString(6);
					user = new UserVO(userid,password,email,lolID,soloRank,freeRank);
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				DBHelper.close(stmt);
			}
			
			return user;
		}
		
		   @Override
		   public boolean NickCheck(String lolID) {
		      conn = DBHelper.getConnection();
		      try {
		         stmt = conn.createStatement();
		         String query = "SELECT lolID FROM usertbl WHERE lolID = '" + lolID + "'";
		         rs = stmt.executeQuery(query);
		         while (rs.next()) {

		            String nick = rs.getString(1);

		            System.out.println("lolid: "+lolID);
		            System.out.println("nick: "+ nick);
		            if (lolID.equals(nick)) {
		               System.out.println("중복된 닉네임 입니다.");
		               return false;
		            }
		         }


		      } catch (SQLException e) {
		      } finally {
		         try {
		            if (rs != null) {
		               rs.close();
		            }
		         } catch (Exception e) {
		         }
		         try {
		            if (stmt != null) {
		               stmt.close();
		            }
		         } catch (Exception e) {
		         }
		      }
		      return true;
		   }


		@Override
		public boolean updateUser(UserVO userVO) {
			
			boolean isOK = false;
			int result = 0;
			
			conn = DBHelper.getConnection();
			
			try {
			stmt = conn.createStatement();

			String query = "UPDATE usertbl set password = '"+userVO.getPassword()+"'"
					+ ", email = '"+userVO.getEmail()+"'"
					+ ", lolID = '"+userVO.getLolID()+"'"
					+ ", soloRank = '"+userVO.getSoloRank()+"'"
					+ ", freeRank = '"+userVO.getFreeRank()+"'"
					+ " WHERE userID = '"+userVO.getUserID()+"'";
				result = stmt.executeUpdate(query);
			} catch (SQLException e) {
				System.out.println("Insert 오류  : " + e.getMessage());
			} finally {
				try {
					if(stmt != null) {
						stmt.close();
					}
				} catch (SQLException e) {}
			}
			
			if(result > 0) {
				isOK = true;
			}else {
				isOK = false;
			}
			
			return isOK;
		}
		@Override
		public boolean idCheck(String userID) {
			conn = DBHelper.getConnection();
			try {
				stmt = conn.createStatement();
				String query = "SELECT userID FROM usertbl WHERE userID = '" + userID + "'";
				rs = stmt.executeQuery(query);
				while (rs.next()) {

					String id = rs.getString(1);

					System.out.println("id :" + id);
					System.out.println("userID :" + userID);

					if (userID.equals(id)) {
						System.out.println("중복된 아이디입니다.");
						return false;
					}
				}


			} catch (SQLException e) {
			} finally {
				try {
					if (rs != null) {
						rs.close();
					}
				} catch (Exception e) {
				}
				try {
					if (stmt != null) {
						stmt.close();
					}
				} catch (Exception e) {
				}
			}
			return true;
		}
		@Override
		public String idReturn(String searchId) {
			String[] strs = searchId.split("\\|");
			conn = DBHelper.getConnection();
			try {
				stmt = conn.createStatement();
				String query = "SELECT * FROM usertbl WHERE email = '" + strs[0] + "' and lolID = '"+strs[1]+"'";
				rs = stmt.executeQuery(query);
				while (rs.next()) {

					String checkID = rs.getString(1);
					
					return checkID;

				}
			} catch (SQLException e) {
			} finally {
				try {
					if (rs != null) {
						rs.close();
					}
				} catch (Exception e) {
				}
				try {
					if (stmt != null) {
						stmt.close();
					}
				} catch (Exception e) {
				}
			}
			return "";
		}
		
		@Override
		public String pwReturn(String searchPw) {
			String strs[] = searchPw.split("\\|");
			String id = strs[0];
			String mail = strs[1];
			String lolid = strs[2];
			conn = DBHelper.getConnection();
			try {
				stmt = conn.createStatement();
				String query = "SELECT * FROM usertbl WHERE userID = '"+id+"' and email = '" + mail + "' and lolID = '"+lolid+"'";
				rs = stmt.executeQuery(query);
				System.out.println(rs);
				
				while (rs.next()) {
					
					String checkPw = rs.getString(2);
					return checkPw;
				}
			} catch (SQLException e) {
			} finally {
				try {
					if (rs != null) {
						rs.close();
					}
				} catch (Exception e) {
				}
				try {
					if (stmt != null) {
						stmt.close();
					}
				} catch (Exception e) {
				}
			}
			return "";
		}

}
		

	

