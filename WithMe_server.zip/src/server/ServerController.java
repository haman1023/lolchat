package server;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Vector;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import server.ServerController.Client;
import server.db.stmt.Usertbl;
import vo.MessageVO;
import vo.RoomVO;
import vo.UserVO;

public class ServerController implements Initializable {

	public static final int SERVER_PORT = 5001;

	@FXML
	private TextArea txtDisplay;
	@FXML
	private Button btnStartStop;
	private int roomNumber = 0;
	Usertbl dbController = new Usertbl();

	ExecutorService threads;
	ServerSocket server;

	List<Client> connections = new Vector<>();
	List<RoomVO> roomList = new Vector<>();

	class Client {
		Socket socket;
		UserVO user;
		RoomVO room;

		Client(Socket socket) {
			this.socket = socket;
			receive();
		}

		// data 받기
		public void receive() {

			Runnable runable = new Runnable() {
				@Override
				public void run() {
					while (true) {
						try {
							InputStream is = socket.getInputStream();
							ObjectInputStream ois = new ObjectInputStream(is);

							Platform.runLater(() -> displayText("[요청 처리 " + socket.getRemoteSocketAddress() + "]"));

							MessageVO data = (MessageVO) ois.readObject();

							System.out.println(data.getCode() + "번 기능 실행");

							switch (data.getCode()) {
							case 1: // 회원가입 요청
								boolean isSignUp = dbController.insert((UserVO) data.getMessge());
								MessageVO sMVO1 = new MessageVO(1, isSignUp);
								send(sMVO1);

								break;
							case 2: // 아이디 중복확인
								boolean idCheck = dbController.idCheck((String) data.getMessge());
								MessageVO sMVO2 = new MessageVO(2, idCheck);
								send(sMVO2);
								break;
							case 3: // 아이디 찾기
								String id = dbController.idReturn((String) data.getMessge());
								MessageVO sMVO3 = new MessageVO(3, id);
								send(sMVO3);

								break;
							case 4: // 비밀번호 찾기
								String pw = dbController.pwReturn((String) data.getMessge());
								MessageVO sMVO4 = new MessageVO(4, pw);
								send(sMVO4);

								break;
							case 5: // 로그인
								String loginMsg = (String) data.getMessge();
								String[] strs = loginMsg.split("\\|");
								UserVO userVO = dbController.Select(strs[0].toString(), strs[1].toString());
								boolean islogin = false;
								for (Client c : connections) {
									if (userVO != null && c.user != null
											&& c.user.getUserID().equals(userVO.getUserID())) {
										islogin = true;
									}
								}
								if (userVO != null && !islogin) { // 로그인 성공
									MessageVO sMVO = new MessageVO(5, userVO);
									send(sMVO);
									Client.this.user = userVO;
								} else { // 로그인 실패
									if (userVO == null) {
										MessageVO sMVO = new MessageVO(14, "failed");
										send(sMVO);
										break;
									} else {
										MessageVO sMVO = new MessageVO(15, "failed");
										send(sMVO);
									}
								}
								break;

							case 6:
								boolean nickCheck = dbController.NickCheck((String) data.getMessge());
								MessageVO sMVO6 = new MessageVO(6, nickCheck);
								send(sMVO6);
								break;
								
							case 11: // 방생성
								createRoom(data);
								break;
								
							case 12: // 정보수정, 롤아이디 중복확인 요청
								String updateLolID = (String) data.getMessge();
								boolean ischeck = dbController.NickCheck(updateLolID);
								MessageVO sMVO12 = new MessageVO(12, ischeck);
								send(sMVO12);

								break;

							case 13: // 정보 수정 요청
								UserVO newUser = (UserVO) data.getMessge();
								boolean isUpdate = dbController.updateUser(newUser);
								Client.this.user = newUser;
								System.out.println(isUpdate);
								MessageVO sMVO13 = new MessageVO(13, isUpdate);
								send(sMVO13);
								break;

							case 21: // 채팅방 입장
								
								System.out.println((RoomVO)data.getMessge());
								enterRoom(data);

								for (Client client : connections) {
									if ((client.room != null)
											&& (Client.this.room.getRoomNumber() == client.room.getRoomNumber())) {
										client.drawUserList(room);
									}
								}
								break;

							case 22: // 채팅방 퇴장
								if (room == null)
									break; // 방이 없을 경우 바로 종료
								exitRoom(data);

								for (Client client : connections) {
									if ((client.room != null) && (Client.this != client)
											&& (Client.this.room.getRoomNumber() == client.room.getRoomNumber())) {
										client.drawUserList(room);
									}
								}
								room = null;
								break;

							case 23: // 채팅 메세지 받기
								send(data);
								broadcastMessage((String) data.getMessge());
								break;

							case 25: // 유저 강퇴
								kickUser(data.getMessge());
//									broadcastMessage((String)data.getMessge());
								break;

							case 26: // 룸마스터 채팅방 퇴장
								if (room == null)
									break; // 방이 없을 경우 바로 종료
								
								exitRoom(data);
								
								for (Client client : connections) {
									if ((client.room != null) && (Client.this != client)
											&& (Client.this.room.getRoomNumber() == client.room.getRoomNumber())) {
										kickUser(client.user);
//										client.drawUserList(room);
									}
								}

								roomList.remove(room);
								room = null;
//								MessageVO messageRemove = new MessageVO(31, roomList);
//								broadCastList(messageRemove);
								break;

							case 31: // 전체 리스트 요청
								MessageVO msg = new MessageVO(31, roomList);
								send(msg);
								break;

							case 35: // 검색 요청
								String message = (String) data.getMessge();
								searchRequest(message);
								break;

							}
						} catch (Exception e) {
							String message = "[클라이언트 통신 안됨 : " + socket.getRemoteSocketAddress() + "]";
							Platform.runLater(() -> displayText(message));
							connections.remove(Client.this);
							try {
								socket.close();
							} catch (IOException e1) {
							}
							break;
						}
					}
				}
			};
			threads.submit(runable);
		}

		// Client로 data 전달
		public void send(MessageVO data) {

			try {
				OutputStream os = socket.getOutputStream();
				ObjectOutputStream oos = new ObjectOutputStream(os);
				oos.writeObject(data);
				oos.flush();
			} catch (Exception e) {
				String message = "[클라이언트 통신 안됨 : " + socket.getRemoteSocketAddress() + "]";
				Platform.runLater(() -> displayText(message));
				connections.remove(Client.this);
				try {
					socket.close();
				} catch (IOException e1) {
				}
			}
		}

		// 11: 방생성
		protected void createRoom(MessageVO<RoomVO> data) {
			RoomVO newRoom = (RoomVO) data.getMessge();
			roomList.add(newRoom);
			Client.this.room = newRoom;

			MessageVO message = new MessageVO(33, roomList);
			broadCastList(message);
		}

		// 21: 채팅방 입장
		protected void enterRoom(MessageVO data) {

			RoomVO rvo = (RoomVO) data.getMessge();
			int index = searchRoom(rvo);
			roomList.set(index, rvo);
			roomList.get(index).enterUser(user);
			Client.this.room = roomList.get(index);

			// 본인에게 입장 메세지 뿌리기
			String message = room.getRoomNumber() + "번 방에 입장 하셨습니다.";
			System.out.println(message);
			MessageVO enterMessage = new MessageVO(23, message);
			send(enterMessage);

			// 입장 메세지 같은 방 유저들에게 뿌리기
			String broadcastData;
			if (user != null) {
				broadcastData = user.getLolID() + "님이 입장하셨습니다.";
			} else {
				broadcastData = "익명유저가 입장하셨습니다.";
			}
			broadcastMessage(broadcastData); // 본인 제외 출력

			// 입장으로 인해 변경된 방 정보를 뿌려준다.
			MessageVO roomListMessage = new MessageVO(34, roomList);
			broadCastList(roomListMessage);
		}

		// 22: 채팅방 퇴장
		protected void exitRoom(MessageVO data) {

			RoomVO rvo = (RoomVO) data.getMessge();
			int index = searchRoom(rvo);
			room = rvo;
			roomList.set(index, rvo);

			String message;
			if (user != null) {
				message = user.getLolID() + "님이 퇴장하셨습니다.";
			} else {
				message = "익명유저가 퇴장하셨습니다.";
			}
			System.out.println(message);
			broadcastMessage(message);

			room.exitUser(user);
			if (room.getUserList().isEmpty()) {
				System.out.println("방이 사라집니다.");
				roomList.remove(room);
			} else {
				System.out.println("방이 안사라집니다.");
			}
			// 퇴장이 후 변경된 방 정보를 뿌려준다.
			MessageVO roomListMessage = new MessageVO(34, roomList);
			broadCastList(roomListMessage);
		}

		// 23: 본인 제외 유저들에게 메세지 전달
		protected void broadcastMessage(String data) {
			for (Client client : connections) {
				if ((client != Client.this) && (client.room != null)
						&& (Client.this.room.getRoomNumber() == client.room.getRoomNumber())) {
					if (user != null) {
						String message = user.getLolID() + " : " + data;
						MessageVO<String> broadMessage = new MessageVO<>(23, message);
						client.send(broadMessage);
					} else {
						String message = "익명 : " + data;
						MessageVO<String> broadMessage = new MessageVO<>(23, message);
						client.send(broadMessage);
					}
				}
			}
		}

		// 24: 유저리스트 그리기
		protected void drawUserList(RoomVO room) {
			MessageVO<RoomVO> data = new MessageVO<>(24, room); // 24 : 유저 리스트 그리기
			send(data);
		}

		// 25: 유저 강퇴
		protected void kickUser(Object message) {
			UserVO kickUserVO = (UserVO) message;
			for (Client client : connections) {
				if (client.user.getLolID().equals(kickUserVO.getLolID())) {
					MessageVO<String> data = new MessageVO<>(25, "강퇴");
					client.send(data);
				}
			}
		}

		// 35: 방검색
		public void searchRequest(String roomName) {
			List<RoomVO> list = new ArrayList<>();

			for (RoomVO room : roomList) {
				if (room.getTitle().contains(roomName)) {
					list.add(room);
				}
			}
			System.out.println(list.size());
			MessageVO data = new MessageVO(31, list);
			send(data);
		}

		// 룸 리스트 Main에 그려주기
		public void broadCastList(MessageVO message) {
			Iterator<Client> itr = connections.iterator();
			while (itr.hasNext()) {
				try {
					Client c = itr.next();
					ObjectOutputStream oos = new ObjectOutputStream(c.socket.getOutputStream());
					oos.writeObject(message);
					oos.flush();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		// 룸리스트에서 접속한 방 찾기(인덱스 반환)
		public int searchRoom(RoomVO room) { //
			int isRoom = -1;
			for (int i = 0; i < roomList.size(); i++) {
				RoomVO rvo = roomList.get(i);

				if (rvo.getRoomNumber() == room.getRoomNumber()) {
					isRoom = i;
					break;
				}
			}
			return isRoom;
		}

		// 미구현 기능
		protected void setPosition(UserVO user2, RoomVO roomVO) {

		}
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		btnStartStop.setOnAction(event -> handleBtnStartStop(event));
	}

	private void handleBtnStartStop(ActionEvent event) {
		System.out.println("Click");
		System.out.println(btnStartStop.getText());
		if (btnStartStop.getText().equals("start")) {
			startServer();
		} else {
			stopServer();
		}
	}

	public void startServer() {
		threads = Executors.newFixedThreadPool(30);

		try {
			server = new ServerSocket(SERVER_PORT);

			Platform.runLater(() -> {
				btnStartStop.setText("stop");
				displayText("서버시작");
			});
		} catch (IOException e) {
			stopServer();
			System.out.println("startServer 오류");
			return;
		}

		Runnable runnable = new Runnable() {
			@Override
			public void run() {
				while (true) {
					try {
						Socket socket = server.accept();
						String message = "[연결수락 : ]" + socket.getRemoteSocketAddress();
						System.out.println(message);

						Platform.runLater(() -> displayText(message));

						Client client = new Client(socket);
						connections.add(client);

						Platform.runLater(() -> displayText("[연결 Client 수 : " + connections.size() + "]"));

					} catch (IOException e) {
						stopServer();
						System.out.println("startServer Runnable 오류");
						break;
					}
				}
			}
		};
		threads.submit(runnable);
	}

	public void stopServer() {

		try {
			Iterator<Client> iterator = connections.iterator();
			while (iterator.hasNext()) {
				Client client = iterator.next();
				if (client.socket != null && !client.socket.isClosed()) {
					client.socket.close();
					iterator.remove();
				}
			}

			if (server != null && !server.isClosed()) {
				server.close();
			}

			if (threads != null && !threads.isShutdown()) {
				threads.shutdown();
			}

			Platform.runLater(() -> {
				btnStartStop.setText("start");
				displayText("[서버종료]");
			});

		} catch (IOException e) {
			System.out.println("stopServer 오류");
		}

	}

	void displayText(String text) {
		txtDisplay.appendText(text + "\n");
	}
}
