package vo;

import java.io.Serializable;

public class MessageVO<T> implements Serializable{
	
	private static final long serialVersionUID = 30L;
	
	private int code;
	private T messge;

	public MessageVO(int code, T messge) {
		this.code = code;
		this.messge = messge;
	}

	public int getCode() {
		return code;
	}

	public T getMessge() {
		return messge;
	}
}
