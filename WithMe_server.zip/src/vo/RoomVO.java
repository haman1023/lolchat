package vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

import javafx.scene.control.Button;

public class RoomVO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 40L;
	private int roomNumber;
	private int roomType; 	//	0: solo, 1: free, 2: normal, 3: ARAM
	private String title;
	private UserVO masterUser;
	private int limit;
	private String tier;
	private String password;
	
//	private Button btn;
//	
//	
//	public Button getBtn() {
//		return btn;
//	}
//	public void setBtn(Button btn) {
//		this.btn = btn;
//	}

	private ArrayList<UserVO> userList;
	private boolean[] position = new boolean[5];	//	0: top, 1: jungle, 2: mid, 3: bottom, 4: sup
	
	public RoomVO() {}
	public RoomVO(int roomNumber, int roomType, String title, UserVO masterUser, int position, int limit) {
		this.roomNumber = roomNumber; 
		this.roomType = roomType;
		this.title = title;
		this.masterUser = masterUser;
		this.position[position] = true;
		this.limit = limit;
		
		if(roomType == 0) {
			userList = new ArrayList<UserVO>(2);
		}else{
			userList = new ArrayList<UserVO>(5);
		}
	}

	public void setEnterPosition(int position) {
		this.position[position-1] = true;
	}
	
	public void setExitPosition(int position) {
		this.position[position-1] = false;
	}
	
	public void setRoomNumber(int roomNumber) {
		this.roomNumber = roomNumber;
	}
	public String getTier() {
		return tier;
	}
	public void setTier(String tier) {
		this.tier = tier;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	
	public int getLimit() {
		return limit;
	}
	public void setLimit(int limit) {
		this.limit = limit;
	}
	public int getRoomNumber() {
		return roomNumber;
	}

	public int getRoomType() {
		return roomType;
	}

	public String getTitle() {
		return title;
	}

	public UserVO getMasterUser() {
		return masterUser;
	}

	public void setMasterUser(UserVO masterUserID) {
		this.masterUser = masterUserID;
	}

	public ArrayList<UserVO> getUserList() {
		return userList;
	}
	
	public void enterUser(UserVO user) {
		this.userList.add(user);
	}
	
	public void exitUser(UserVO user) {
		this.userList.remove(user);
	}

	public void setPosition(boolean[] position) {
		this.position = position;
	}
	
	public boolean[] getPosition() {
		return position;
	}

	@Override
	public String toString() {
		String type;
		if(roomType == 0) {
			type = "솔로";
		}else if(roomType == 1) {
			type = "자유";
		}else if(roomType == 2) {
			type = "일반";
		}else{
			type = "칼바람";
		}
		return "[방번호=" + roomNumber + ", 유형=" + type + ", 방제=" + title + ", position="
				+ Arrays.toString(position) + "]";
	}
	
	
}
